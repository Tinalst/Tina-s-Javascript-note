import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { SenceComponent } from './sence/sence.component';
import { ThirdComponent } from './third/third.component';
import { FastFoodComponent } from './fast-food/fast-food.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SenceComponent,
    ThirdComponent,
    FastFoodComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
